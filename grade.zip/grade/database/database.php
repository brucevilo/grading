<?php
class Database{
    public $servername ="localhost";
    public $username = "root";
    public $password = "";
    public $dbname = "vilo";
    private $con;


    public function __construct(){
            $this->con = mysqli_connect($this->servername,$this->username,$this->password,$this->dbname);
            
    }
    public function execute($sql){
        return mysqli_query($this->con,$sql);
    } 
 
}//end of class


?>