<?php
  
    require'../database/database.php';

    class gradeModel extends Database{
        public $firstname;
        public $lastname;
        public $email;
        public $password;
        public $user_type;
        public $section;
        public $subject;
        public $year;
        public $time_from;
        public $time_to;
        public $day;
        public $student_id;
        public $subject_id;
        public $tech_id;
        public $grade;
        

    public function __construct()
        {
        $db = new Database();
         }
         
         public function Student()
         {
            $db =new Database();
            $sql ="SELECT * FROM students";
            $db->execute($sql);
        }
        
     public function AddGrade()
         {  
            $db = new Database();
              $sql = "INSERT INTO grade(grade,tech_id,student_id,subject_id)
                        VALUES ('$this->grade','$this->tech_id','$this->student_id','$this->subject_id')";
            
            return $db->execute($sql);
         }
         
     public function Grade($student_id)
         {  
            $db = new Database();
              $sql = "SELECT DISTINCT student.student_id, subject.subject_id , teacher.tech_id 
              FROM teacher,subject,student
              where student_id =".$student_id;
              
            return $db->execute($sql);
         }
      
         
     public function password($newpass,$id)
         {  
            $db = new Database();
              $sql ="UPDATE accounts SET password = '$newpass' where id=".$id ;
            return $db->execute($sql);
         }
         public function EditStudent()

         {           $db = new Database();
                 $sql="UPDATE student SET firstname = '$this->firstname', lastname = '$this->lastname', email ='$this->email' 
                 where student_id=".$this->student_id ;
                //  echo $sql ; die;
                return $db->execute($sql);
          }
        public function Student_Id()
        {   
            $db = new Database();              
            $sql ="SELECT student_id 
                    FROM student
                     WHERE email= "."'".$_SESSION['student']."'";

            return $db->execute($sql);
        }

  public function Insert($user_type)
         {
             $db = new Database();
             $sql = "INSERT INTO accounts(firstname,lastname,email,password,user_type) VALUES 
             ('$this->firstname','$this->lastname','$this->email','$this->password','$this->user_type')";
            //  echo $sql; die;
             return $db->execute($sql);
         }

    public function InsertTeacher()
        {
            $db = new Database();
            $sql = "INSERT INTO teacher (firstname,lastname,email,password) VALUES 
            ('$this->firstname','$this->lastname','$this->email','$this->password')";
            return $db->execute($sql);
        }
    public function InsertSection()
        {
               $db = new Database();
               $sql ="INSERT INTO section (teacher,year,section) VALUES
               ('$this->teacher','$this->year','$this->section')"; 
            //    echo $sql; die;  
               return $db->execute($sql);
        }
        public function InsertSubject()
        {
               $db = new Database();
               $sql ="INSERT INTO subject (subject,time_from,time_to,day,section,teacher) VALUES
               ('$this->subject','$this->time_from','$this->time_to','$this->day','$this->section','$this->teacher')"; 
            //    echo $sql; die;  
               return $db->execute($sql);
        }
      public function TeacherGrade()
            {
                $db = new Database();   
                $sql="SELECT DISTINCT student.student_id,student.lastname , student.section, student.firstname
                 FROM subject , student 
                  WHERE student.section = subject.section ";
                //   echo $sql ; die;
                return $db->execute($sql);    
        }  
      public function ViewTeacher()
        {
            $db = new Database();
            $sql = "SELECT teacher.firstname,teacher.lastname , teacher.email, section.section 
            FROM teacher ,section
            WHERE teacher.lastname = section.teacher ";
            return $db->execute($sql);          
        }
        public function TeacherSubjects()
        {
            $db = new Database();
    
            $sql = "SELECT subject.subject_id, subject.section, subject.day ,subject.subject , subject.time_from , subject.time_to 
             FROM subject ,teacher
              where subject.teacher = teacher.lastname";
            return $db->execute($sql);
        }

     public function ViewAccounts()
        {
            $db = new Database();
            $sql = "SELECT * FROM accounts";
            return $db->execute($sql);
        }


    public function ViewSection()
        {
            $db = new Database();
            $sql = "SELECT * FROM section";
            return $db->execute($sql);
        }
        
    public function ViewSubjects()
        {
            $db = new Database();
            $sql = "SELECT * FROM subject";
            return $db->execute($sql);
        }
       
        public function StudentId()
        {
            $db = new Database();

            $sql = "SELECT * FROM student where email =".$_SESSION['student']."";
            echo $sql;
          
          return $db->execute($sql);
        }
              
               
    public function ViewMySubjects($student_id)
        {
            $db = new Database();
        
            $sql = "SELECT grade.grade_id , subject.subject , subject.time_from, subject.time_to, subject.day
            FROM subject, student , grade
            where student.student_id = $student_id
            ";
      
            return $db->execute($sql);
        }    
    public function InsertStudent()
        {
            $db = new Database();
            $sql = "INSERT INTO student(firstname,lastname,year,section,email,password) VALUES 
            ('$this->firstname','$this->lastname','$this->year','$this->section','$this->email','$this->password')";
            // echo $sql; die;
            return $db->execute($sql);
        }    
    public function ViewStudent()
        {
            $db = new Database();
            $sql = "SELECT * FROM student";
            return $db->execute($sql);
        }
    
    public function ViewGrade($student_id,$subject_id,$teacher_id)
        {
            
            $db = new Database();
            $sql = "SELECT * FROM grade where student_id = $student_id AND  tech_id = $teacher_id  AND subject_id = $subject_id";
            // echo $sql; die;
            return $db->execute($sql);
        }
    public function StudentGrade($grade_id){
        $db = new Database();
        $sql  ="SELECT grade FROM grade where grade_id =$grade_id";
        // echo $sql; die;
        return $db->execute($sql);
    }    
    public function Login()
        {
            $db = new Database();
            $sql = "SELECT * FROM accounts WHERE email = '$this->email' and password = '$this->password'";
        // echo $sql; die;
            return $db->execute($sql);
        }
             
    public function DisplayLogs($id)
    {$db = new Database();
            $sql = "SELECT * FROM user_log where id =".$id; 
           return $db->execute($sql);     
    }

    public function logs($action){
    // $id = $_SESSION['id'];
    $db = new Database();
    $sql = "INSERT INTO user_log(action,ip_address,id,date)
            VALUES
            ('$this->action','$this->ip_address','$this->id',NOW())"; 
    
    return $db->execute($sql);        
             }
    public function maxId(){
        $db = new Database();
    $sql =  "SELECT MAX(id) as id FROM accounts";   
//    echo $sql; die;
    return $db->execute($sql);        
            }    

}



?>