<?php
    include('header.php');
?>

  <body class="bg-dark">
  <form method = "POST" action ="../controller/register.php">
    <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header">Book Schedule</div>
        <div class="card-body">
     
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" name="firstname" id="firstName" class="form-control" placeholder="First name" required="required" autofocus="autofocus">
                    <label for="firstName">First name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" name="lastname" id="lastName" class="form-control" placeholder="Last name" required="required">
                    <label for="lastName">Last name</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="email"  name ="email" id="inputEmail" class="form-control" placeholder="Email address" required="required">
                <label for="inputEmail">Phone Number</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="Section"  name ="Section" id="Section" class="form-control" placeholder="Section" required="required">
                <label for="Section">Address</label>
              </div>
            </div>
          
          <h3>Check Car Problems</h3>
            
              <div class="form-check">
                 <input type="checkbox" class="form-check-input" id="exampleCheck1">
                 <label class="form-check-label" for="exampleCheck1">Engine</label>
             </div>
            <div class="form-check">
                 <input type="checkbox" class="form-check-input" id="exampleCheck1">
                 <label class="form-check-label" for="exampleCheck1">Break</label>
            </div>
  <div class="form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Tires</label>
  </div>
  <div class="form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Oil</label>
  </div>
  <div class="form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Electrical</label>
  </div>
  <div class="form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <div class="form-check">
    <input type="text" class="form-check-input" id="exampleCheck1" placeholder="Other problem">
  </div>
<br>
<br>
<div class="form-group">
  <label for="comment">Description</label>
  <textarea class="form-control" rows="5" id="comment"></textarea>
</div>
<div class="">
<label for="">Date</label>
<input type="date" name="bday">
</div>
<div class="">
<label for="">Time: From</label>
<input type="time" name="bday">
<label for="">To</label>
<input type="time" name="bday">

</div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="password" name ="password" id="inputPassword" class="form-control" placeholder="Password" required="required">
                    <label for="inputPassword">Password</label>
                  </div>
                </div>
               
              </div>
            </div>
            <button class="btn btn-danger btn-block"  name ="btn_reg_student" type="submit" >Book Now</button>
          </form>
          <div class="text-center">
            <a class="d-block small mt-3" href="index.php">Back</a>
          </div>
        </div>
      </div>
    </div>
    
    <script type="text/javascript">
    $(".form_datetime").datetimepicker({
        format: "dd MM yyyy - hh:ii"
    });
</script>  
<?php
  include('footer.php');
?>
