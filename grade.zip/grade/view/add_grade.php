<?php
session_start();
      require'../model/grademodel.php';
        include("header.php");
      ?>

<div class="container" align = "middle" style= "margin-top: 10%; margin-right:auto; ">
<form class="form-signin" action = "../controller/edit_student.php" method = "GET" >

<div class ="container"  >

        <h2 class="form-signin-heading">Add Grade</h2>
        <?php        
        $student_id =$_GET['student_id'];
       $gm = new gradeModel();
       $gm->student_id=$student_id;
      

        $result =$gm->Grade($student_id);
        $data = mysqli_fetch_assoc($result);
        $teacher_id =$_SESSION['tech_id'];
        $student_id =$data['student_id'];
         $subject_id =$data['subject_id']; 
       $rs = $gm->ViewGrade($student_id,$subject_id,$teacher_id);
       $grade = mysqli_fetch_assoc($rs);
       echo "<h2> Your Grade: ".$grade['grade']."<h2>";
        ?> 
        <input type="hidden" name="subject_id" class="form-control" style = "width :50%" value ="<?php echo $data['subject_id'];?>"><br/>
        <input type="hidden" name="student_id" class="form-control" style = "width :50%" value ="<?php echo $data['student_id'];?>"><br/>
        <input type="hidden" name="tech_id" class="form-control" style = "width :50%" value ="<?php echo $_SESSION['tech_id'];?>"><br/>
        
    Input Grade: <input type="number"  max="5.0" min="1.0" step="0.1" name="grade" id="grade"  placeholder="0.0">


    <br>
    <br>
     
        </div>
        <button class="btn btn-lg btn-primary btn-block" name = "btn_AddGrade" class="form-control" style = "width :30%"type="submit">Save</button>
        <a class="btn btn-lg btn-primary btn-block" style = "width :30%" href="teacher_view.php">Cancel</a>
        </div>
      
        </div>   
     
</body>
</html>