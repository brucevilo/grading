<?php
      require'../model/grademodel.php';
        include("header.php");
      ?>

<div class="container" align = "middle" style= "margin-top: 10%; margin-right:auto; ">
<form class="form-signin" action = "../controller/edit_student.php" method = "GET" >

<div class ="container"  >

        <h2 class="form-signin-heading">Edit User</h2>
        <?php        
        $student_id =$_GET['student_id'];
       $gm = new gradeModel();
       $gm->student_id=$student_id;
        $result =$gm->Student_Id();
        $data = mysqli_fetch_assoc($result);
        ?>

        <input type="hidden" name="id" class="form-control" style = "width :50%" value ="<?php echo $data['student_id'];?>"><br/>
      First Name:  
      <input type="text" name="firstname" class="form-control" style = "width :50%" value ="<?php echo $data['firstname'];?>">
      Last Name: 
      <input type="text" name="lastname"  class="form-control"  style = "width :50%" value ="<?php echo $data['lastname'];?>" ><br/>
      Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="text" name="email"  class="form-control"  style = "width :50%" value ="<?php echo $data['email'];?>" ><br/>

     
        </div>
        <button class="btn btn-lg btn-primary btn-block" name = "btn_edit" class="form-control" style = "width :30%"type="submit">Save</button>
        <a class="btn btn-lg btn-primary btn-block" style = "width :30%" href="teacher_view.php">Cancel</a>
        </div>
      
        </div>   
     
</body>
</html>