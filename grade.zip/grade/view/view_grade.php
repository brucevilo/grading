<?php
session_start();
      require'../model/grademodel.php';
        include("header.php");
      ?>

<div class="container" align = "middle" style= "margin-top: 10%; margin-right:auto; ">
<form class="form-signin" action = "../controller/edit_student.php" method = "GET" >

<div class ="container"  >

        <h2 class="form-signin-heading">Add Grade</h2>
        <?php        
        $grade_id =$_REQUEST['grade'];

        
       $gm = new gradeModel();
       $gm->grade_id=$grade_id;
      

        $result =$gm->StudentGrade($grade_id);
        $data = mysqli_fetch_assoc($result);
       echo "<h2> Your Grade is: ".$data['grade']."<h2>";
        ?> 
      
    <br>
    <br>
     
        </div>

        <a class="btn btn-lg btn-primary btn-block" style = "width :30%" href="student_view.php">Cancel</a>
        </div>
      
        </div>   
     
</body>
</html>