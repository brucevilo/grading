<?php
    include('header.php');
    require('../model/gradeModel.php');
?>

  <body class="bg-dark">
  <form method = "POST" action ="../controller/register.php">
    <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header">Add Student</div>
        <div class="card-body">
     
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" name="firstname" id="firstName" class="form-control" placeholder="First name" required="required" autofocus="autofocus">
                    <label for="firstName">First name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" name="lastname" id="lastName" class="form-control" placeholder="Last name" required="required">
                    <label for="lastName">Last name</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="email"  name ="email" id="inputEmail" class="form-control" placeholder="Email address" required="required">
                <label for="inputEmail">Email address</label>
              </div>
            </div>
          
            <div class="form-group col-md-6">
                <label for="inputState">Year</label>
                <select name="year" class="form-control">
                <?php
                
                ?>
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                </select>
             
                <?php
                    $gm = new gradeModel();
                    $result = $gm->ViewSection();
               ?>
                    <select name ="section" class="form-control">
                      <option >Select Section </option>
              <?php
                      while($data=mysqli_fetch_assoc($result))
                    {
               ?>
                    <option value="<?php echo $data['section'];?>">
                    <?php echo $data['section'];?>
                    </option>

             <?php
                 }
             ?>
                  </select>                                 
               
              </div>


            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="password" name ="password" id="inputPassword" class="form-control" placeholder="Password" required="required">
                    <label for="inputPassword">Password</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="password" name="cpass" id="confirmPassword" class="form-control" placeholder="Confirm password" required="required">
                    <label for="confirmPassword">Confirm password</label>
                  </div>
                </div>
              </div>
            </div>
            <button class="btn btn-primary btn-block"  name ="btn_reg_student" type="submit" >Register</button>
          </form>
          <div class="text-center">
            <a class="d-block small mt-3" href="index.php">Back</a>
          </div>
        </div>
      </div>
    </div>
<?php
  include('footer.php');
?>
