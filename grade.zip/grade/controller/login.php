<?php
session_start();


require'../model/gradeModel.php';
// require'../Database/Database.php';
if(isset($_POST['btnLogin']))  {
                $email =$_POST['email'];
            $password = $_POST['password']; 

            $gm= new gradeModel();
            // $objdata = new Database();
            $gm->email =$email;
            $password = md5($password);  
            $gm->password =$password;

            $result = $gm->Login();
            // var_dump($result); 
            $data=mysqli_fetch_assoc($result);
            $num_rows=mysqli_num_rows($result);
            // $data['user_type'];
            $id =  $data['id'];
            if($num_rows > 0 ){
//             if($data['status']=='inactive'){
//             echo "<script>alert('Your has been deactivated !');window.location = '../view/login.php' </script>";

// }
    if(trim($data['user_type'])==='admin'){

            $_SESSION['admin'] = $email; 
            $_SESSION['id'] = $id;
            $_SESSION['password'] = $password;
            
            $action = "log-in";
            $ip_address = $_SERVER['REMOTE_ADDR'];
            $gm->id=$id;
            $gm->action=$action ;
            $gm->ip_address= $ip_address;
            
            $result = $gm->logs($action);
        
            header("location:../view/index.php");
        }
        else if(trim($data['user_type'])==='Student'){
            $_SESSION['student'] = $email; 
            $_SESSION['id'] = $id;
            $_SESSION['password'] = $password;
           
            
            $action = "log-in";
            $ip_address = $_SERVER['REMOTE_ADDR'];
            $gm->id=$id;
            $gm->action=$action ;
            $gm->ip_address= $ip_address;
            
            $result = $gm->logs($action);
            header("location:../view/student_view.php");
        }

     else{
                
            $_SESSION['teacher'] = $email; 
            $_SESSION['tech_id'] = $id;
            $_SESSION['password'] = $password;
            
           
            $action = "log in";
            $ip_address = $_SERVER['REMOTE_ADDR'];
            $gm->action=$action ;
            $gm->ip_address= $ip_address;
            $gm->id=$id;
            $result = $gm->logs($action);
            header("location:../view/teacher_view.php");
   }
    }
    else{
        // die;
        echo "<script>alert('Failed Login');window.location='../view/login.php'</script>";
}
}
?>