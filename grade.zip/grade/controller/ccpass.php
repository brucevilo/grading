<?php
    require('../model/gradeModel.php');
if(isset($_POST['btn_password_student'])){
        $id = $_POST['id'];
         $pass = $_POST['pass']; 
        $newpass = $_POST['newpass'];
        $cpass = $_POST['cpass'];
       $currentpass= $_POST['currentpass'];
      $current = md5($currentpass);
        // echo $current;
        // echo $pass; die;
          
    
    
                if($pass!=$current) {
                    # code...
                    echo "<script>alert('Incorrect Current Password');window.location='../view/student_view.php'</script>";
                }
                else if($newpass != $cpass) {
           
                    echo "<script>alert('password mismatch!');window.location='../view/student_view.php'</script>";
                   }
          
            else
            {
                 $gm = new gradeModel();       
                 $gm->newpass=$newpass;    
                 $gm->id=$id;    
              
                $newpass = md5($newpass);
                $result=$gm->Password($newpass,$id);
                                //inform the client.php if trans is ok or not
                if($result){
                      
            $action = "Edit Password";
            $ip_address = $_SERVER['REMOTE_ADDR'];
            $objvilo->action=$action ;
            $objvilo->ip_address= $ip_address;
            $objvilo->logs($action);
           
                    echo "<script>alert('Succesfully Change!');window.location='../view/student_view.php'</script>";
                }else{
              
                    echo "<script>alert('Failed Change!');window.location='../view/student_view.php'</script>";
                }
                
            }
        }


        if(isset($_POST['btn_password'])){
            $id = $_POST['id'];
             $pass = $_POST['pass']; 
            $newpass = $_POST['newpass'];
            $cpass = $_POST['cpass'];
           $currentpass= $_POST['currentpass'];
          $current = md5($currentpass);
            // echo $current;
            // echo $pass; die;
              
        
        
                    if($pass!=$current) {
                        # code...
                        echo "<script>alert('Incorrect Current Password');window.location='../view/teacher_view.php'</script>";
                    }
                    else if($newpass != $cpass) {
               
                        echo "<script>alert('password mismatch!');window.location='../view/teacher_view.php''</script>";
                       }
              
                else
                {
                     $gm = new gradeModel();       
                     $gm->newpass=$newpass;    
                     $gm->id=$id;    
                    //encrypt the password
                    //run the query
                    //2 params
                    //1 - con instance 2 - query stringn
                    $newpass = md5($newpass);
                    // $sql_query = "UPDATE accounts SET password = '$newpass' where id=".$id ;
                    $result=$gm->Password($newpass,$id);
                                    //inform the client.php if trans is ok or not
                    if($result){
                          
                $action = "Edit Password";
                $ip_address = $_SERVER['REMOTE_ADDR'];
                $objvilo->action=$action ;
                $objvilo->ip_address= $ip_address;
                $objvilo->logs($action);
               
                        echo "<script>alert('Succesfully Change!');window.location='../view/teacher_view.php'</script>";
                    }else{
                  
                        echo "<script>alert('Failed Change!');window.location='../view/teacher_view.php'</script>";
                    }
                    //get the result of the query
                }
            }
?>       