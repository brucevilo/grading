<?php
    require('../model/gradeModel.php');
        // TEACHER
    if(isset($_POST['btn_reg_teacher']))
    {
      
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];   
        $password = $_POST['password'];
        $cpass = $_POST['cpass'];
        $user_type = "Teacher";    
        if ($cpass != $password)
             {
                 echo "<script>alert('Password mismatch!');window.location='../view/reg_teacher.php'</script>";
             }    
          else {
            $gm = new gradeModel();
                $gm->firstname= $firstname;
                $gm->lastname= $lastname;
                $password = md5($password);
                $gm->password= $password;
                $gm->email= $email;
                $gm->user_type= $user_type;
                $gm->Insert($user_type);
                $gm->InsertTeacher();


                         
                $result = $gm->maxId();
                while($row=mysqli_fetch_assoc($result)){
                    $row['id'];
                $action = " Teacher Register";
                $ip_address = $_SERVER['REMOTE_ADDR'];
                $gm->action=$action ;
                $gm->id=$row['id'];
                $gm->ip_address= $ip_address;
                $gm->logs($action);}

             echo "<script>alert('Successfully Registered.');window.location='../view/login.php'</script>";

          }   
        }
    //  STUDENT
     if(isset($_POST['btn_reg_student']))
          {
            
              $firstname = $_POST['firstname'];
              $lastname = $_POST['lastname'];
              $email = $_POST['email'];   
              $password = $_POST['password'];
              $cpass = $_POST['cpass'];
              $section = $_POST['section'];
              $year = $_POST['year'];
              $user_type = "Student";    
              if ($cpass != $password)
                   {
                       echo "<script>alert('Password mismatch!');window.location='../view/reg_student.php'</script>";
                   }    
                else {
                  $gm = new gradeModel();
                      $gm->firstname= $firstname;
                      $gm->lastname= $lastname;
                      $password = md5($password);
                      $gm->password= $password;
                      $gm->email= $email;
                      $gm->section= $section;
                      $gm->year= $year;
                      $gm->user_type= $user_type;
                      $gm->Insert($user_type);
                      $gm->InsertStudent();
                      

                                    
                        $result = $gm->maxId();
                        while($row=mysqli_fetch_assoc($result)){
                            $row['id'];
                        $action = "Student Register";
                        $ip_address = $_SERVER['REMOTE_ADDR'];
                        $gm->action=$action ;
                        $gm->id=$row['id'];
                        $gm->ip_address= $ip_address;
                        $gm->logs($action);}
                   echo "<script>alert('Successfully Registered.');window.location='../view/login.php'</script>";
      
                }   

    }


?>
