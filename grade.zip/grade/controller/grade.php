<?php
session_start();
require'../model/gradeModel.php';
if(!isset($_SESSION['teacher'])){
    header("locatio:../view/login.php");
}

if(isset($_POST['btn_grade']))
{

    $gm = new gradeModel();
       $grade= $_POST['grade']; 
     $student_id  = $_POST['student_id']; 
     $tech_id  = $_POST['tech_id']; 
     $subject_id  = $_POST['subject_id']; 

    $gm->grade=$grade;
    $gm->student_id=$student_id;
    $gm->tech_id=$tech_id;
    $gm->subject_id=$subject_id;
    $result = $gm->AddGrade();

    if($result)
    {
          
        $action = "Add Grade";
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $objvilo->action=$action ;
        $objvilo->ip_address= $ip_address;
        $objvilo->logs($action);
       
        echo "<script>alert('Grade sucessfully added');window.location='../view/edit_add.php'</script>";
    }
    else
    {
        echo "<script>alert('Grade failed to add');window.location='../view/edit_add.php'</script>";
    }

}

?>