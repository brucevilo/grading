<?php
session_start();
require'../model/gradeModel.php';
if(!isset($_SESSION['teacher'])){
    header("location:../view/login.php");
}
if(isset($_GET['btn_edit'])){
    $student_id = $_GET['id'];
    $firstname = $_GET['firstname'];
    $lastname = $_GET['lastname'];
    $email = $_GET ['email'];

    
    
            //encrypt the password
            //run the query
            //2 params
            // //1 - con instance 2 - query string
            
            $gm = new gradeModel();
           
            $gm->student_id=$student_id;
            $gm->firstname=$firstname;
            $gm->lastname=$lastname;
            $gm->email=$email;
            
            $result = $gm->EditStudent();  
        
             // $sql_query = "UPDATE accounts SET firstname = '$firstname', lastname = '$lastname', email ='$email', username='$username' where student_id=".$student_id ;
            // $result=mysqli_query($con,$sql_query);
                            //inform the client.php if trans is ok or not
            if($result){
                  
            $action = "Edit Student Profile";
            $ip_address = $_SERVER['REMOTE_ADDR'];
            $objvilo->action=$action ;
            $objvilo->ip_address= $ip_address;
            $objvilo->logs($action);
           
                echo "<script>alert('Successfully Update');window.location='../View/edit_add.php'</script>";
                        }
                else{
                    echo "<script>alert('Failed Update');window.location='../View/edit_add.php'</script>";
    
                }        
 }             //get the result of the query
            // ADD GRADE
                 if(isset($_GET['btn_AddGrade']))
                 {
                    $student_id = $_GET['student_id'];
                     $tech_id = $_GET['tech_id'];
                     $subject_id = $_GET['subject_id'];
                     $grade = $_GET['grade'];
                    
                     $gm = new gradeModel();
                     $gm->student_id = $student_id;
                     $gm->tech_id = $tech_id;
                     $gm->subject_id = $subject_id;
                     $gm->grade = $grade;
                     $result = $gm->AddGrade();  

                     if($result)
                     {
                           
            $action = "Add grade";
            $ip_address = $_SERVER['REMOTE_ADDR'];
            $objvilo->action=$action ;
            $objvilo->ip_address= $ip_address;
            $objvilo->logs($action);
           
                         echo"<script>alert('Grade has been Added');window.location='../view/teacher_view.php'</script>";
                     }
                     else{  echo"<script>alert('The student Grade has Already Graded');window.location='../view/teacher_view.php'</script>";}
                 }
?>