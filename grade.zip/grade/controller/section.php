<?php
    require'../model/gradeModel.php';

    if(isset($_POST['btn_section'])){
        $section = $_POST['section'];   
        $teacher = $_POST['lastname'];  
        $year = $_POST['year'];  
    
        $gm = new gradeModel();
        $gm->section = $section;
        $gm->teacher = $teacher;
        $gm->year = $year;
       $result = $gm->InsertSection();
     
     
       if($result){
        echo "<script>alert('Successfully Added..');window.location='../view/section.php'</script>";
        die;
     }
        else{
            echo "<script>alert('Already Existing.');window.location='../view/section.php'</script>";
        }

    }
    
    if(isset($_POST['btn_subject'])){
        $subject = $_POST['subject'];   
        $teacher = $_POST['lastname'];  
        $day = $_POST['day'];  
        $time_from = $_POST['time_from'];  
        $time_to = $_POST['time_to'];  
        $section = $_POST['section'];  
    
        $gm = new gradeModel();
        $gm->section = $section;
        $gm->teacher = $teacher;
        $gm->day = $day;
        $gm->time_from = $time_from;
        $gm->time_to = $time_to;
        $gm->subject = $subject;
     
       $result = $gm->InsertSubject();
     
     
       if($result){
        echo "<script>alert('Successfully Added..');window.location='../view/subject.php'</script>";
        die;
        }
        else{
          
            echo "<script>alert('Already Existing.');window.location='../view/subject.php'</script>";
        }

    }
?>